# R9 Sales — ajustes para ciclos acadêmicos

## Alterações de código
- A configuração operacional filtra `goal_periods` pelo ciclo acadêmico selecionado, além do tipo e das datas.
- A busca de metas dos consultores considera o período operacional do ciclo selecionado.
- As gravações de metas incluem `academic_period` e usam a chave composta compatível com a migração SQL.
- A Home evita falha por múltiplos períodos coincidentes selecionando o período operacional atualizado mais recentemente; o fallback de metas individuais é filtrado pelo ciclo quando há um ciclo definido.
- A importação mantém a versão anterior ativa até que a nova importação e suas linhas diárias sejam gravadas. Só então tenta marcar a anterior como `replaced`.
- Os tipos TypeScript das metas incluem `academic_period`.

## Migração necessária
Execute `MIGRACAO_CICLOS_ACADEMICOS.sql` no Supabase antes de publicar este código. Ela adiciona `goals.academic_period` e substitui a unicidade legada por uma chave que inclui o ciclo acadêmico, preservando registros históricos com `academic_period = NULL`.

## Validação
A instalação das dependências excedeu o tempo limite neste ambiente; portanto, o build completo não foi confirmado. Faça o build e teste de gravação/leitura no seu ambiente antes de publicar.
